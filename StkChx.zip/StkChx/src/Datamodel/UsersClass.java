/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datamodel;

/**
 *
 * @author Warren
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.HashMap;

public class UsersClass {
    
    @JsonProperty("USERID")
    private Integer userID;
    @JsonProperty("USERNAME")
    private String username;
    @JsonProperty ("PASSWORD")
    private String password;
    @JsonProperty("FIRSTNAME")
    private String firstName;
    @JsonProperty ("LASTNAME")
    private String lastName;
    @JsonProperty("LOCATION")
    private Integer location;
    @JsonProperty("SALT")
    private String salt ="";
    
    public UsersClass(){
    }
    
    public UsersClass(Integer userID, String firstName, String lastName, Integer location, String username, String password){
        
        this.userID = userID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.location = location;
        this.username = username;
        
        HashMap<String, String> hashedPassword = HashClass.saltAndHashPassword(password);
        
        this.password = hashedPassword.get("password");
        this.salt = hashedPassword.get("salt");
    }
    
    public Integer getUserID(){
        return userID;
    }
    
    public void setUserID(Integer userID){
        this.userID = userID;
    }
    
    public String getUsername(){
        return username;
    }
    
    public void setUsername(String username){
        this.username = username;
    }
    
    public String getPassword(){
        return password;
    }
    
    public void setPassword(String password){
        HashMap<String, String> hashedPassword = HashClass.saltAndHashPassword(password);
        
        this.password = hashedPassword.get("password");
        this.salt = hashedPassword.get("salt");
    }
    
    public String getFirstName(){
        return firstName;
    }
    
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    
    public Integer getLocation(){
        return location;
    }
    
    public void setLocation(Integer location){
        this.location = location;
    }
    
    public String getSalt(){
        return salt;
    }
    
    public void setSalt(String salt){
        this.salt = salt;
    }
    
}
