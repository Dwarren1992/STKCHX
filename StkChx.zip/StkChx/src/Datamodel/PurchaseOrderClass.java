/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datamodel;

/**
 *
 * @author Warren
 */
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDate;

public class PurchaseOrderClass {
    
    @JsonProperty("PURCHASEORDERID")
    private Integer purchaseOrderID;
    @JsonProperty("PURCHASEORDERDESC")
    private String purchaseOrderDesc;
    @JsonProperty("DEPARTURELOCATION")
    private Integer departureLocation;
    @JsonProperty("ARRIVALLOCATION")
    private Integer arrivalLocation;
    @JsonProperty("DATESENT")
    private String dos;
    private LocalDate dateSent;
    @JsonProperty("ESTIMATEARRIVALDATE")
    private String ead;
    private LocalDate estimateArrivalDate;
    @JsonProperty("QUANTITY")
    private Integer quantity;
    @JsonProperty("PURCHASEORDERITEMID")
    private String purchaseOrderItemID;
    
    public PurchaseOrderClass(){ 
    }
    
    public PurchaseOrderClass(Integer purchaseOrderID, String purchaseOrderDesc, Integer departureLocation, Integer arrivalLocation, LocalDate dateSent, LocalDate estimateArrivalDate, Integer quantity, Integer departWarehouseID, String purchaseOrderItemID){
        
        this.purchaseOrderID = purchaseOrderID;
        this.purchaseOrderDesc = purchaseOrderDesc;
        this.departureLocation = departureLocation;
        this.arrivalLocation = arrivalLocation;
        this.dateSent = dateSent;
        this.estimateArrivalDate = estimateArrivalDate;
        this.quantity = quantity;
        this.purchaseOrderItemID = purchaseOrderItemID;
    }
    
    public Integer getPurchaseOrderID(){
        return purchaseOrderID;
    }
    
    public void setPurchaseOrderID(Integer purchaseOrderID){
        this.purchaseOrderID = purchaseOrderID;
    }
    
    public String getPurchaseOrderDesc(){
        return purchaseOrderDesc;
    }
    
    public void setPurchaseOrderDesc(String purchaseOrderDesc){
        this.purchaseOrderDesc = purchaseOrderDesc;
    }
    
    public Integer getDepartureLocation(){
        return departureLocation;
    }
    
    public void setDepartureLocation(Integer departureLocation){
        this.departureLocation = departureLocation;
    }
    
    public Integer getArrivalLocation(){
        return arrivalLocation;
    }
    
    public void setArrivalLocation(Integer arrivalLocation){
        this.arrivalLocation = arrivalLocation;
    }
    
    public String getDOS(){
        return dos;
    }
    
    public void setDOS(String dos){
        this.dos = dos;
    }
    
    public LocalDate getDateSent(){
        return dateSent;
    }
    
    public void setDateSent(LocalDate dateSent){
        this.dateSent = dateSent;
    }
    
    public String getEAD(){
        return ead;
    }
    
    public void setEAD(String ead){
        this.ead = ead;
    }
    
    public LocalDate getEstimateArrivalDate(){
        return estimateArrivalDate;
    }
    
    public void setEstimateArrivalDate(LocalDate estimateArrivalDate){
        this.estimateArrivalDate = estimateArrivalDate;
    }
    
    public Integer getQuantity(){
        return quantity;
    }
    
    public void setquantity(Integer quantity){
        this.quantity = quantity;
    }
    
    public String getPurchaseOrderItemID(){
        return purchaseOrderItemID;
    }
    
    public void setPurchaseOrderItemID(String purchaseOrderItemID){
        this.purchaseOrderItemID = purchaseOrderItemID;
    }
    
    public void convertDateSent(String dateSentString) {
        this.setDateSent(StringToLocalDate.convertToLocalDate(dateSentString, "yyyy-MM-dd'T'HH:mm:ss"));
    }
    
    public void convertEstimateArrivalDate(String estimateArrivalDateString) {
        this.setEstimateArrivalDate(StringToLocalDate.convertToLocalDate(estimateArrivalDateString, "yyyy-MM-dd'T'HH:mm:ss"));
    }
}
