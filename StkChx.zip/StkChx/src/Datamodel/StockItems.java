/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datamodel;

/**
 *
 * @author Warren
 */
import com.fasterxml.jackson.annotation.JsonProperty;

public class StockItems {
    
    @JsonProperty("STOCKCODE")
    private String stockcode;
    @JsonProperty("STOCKNAME")
    private String stockname;
    @JsonProperty("STORAGELOC")
    private String storageLocation;
    @JsonProperty("OUANTITY")
    private Integer quantity;
    @JsonProperty("STOCKDESC")
    private String stockDescription;
    @JsonProperty("WAREHOUSELOC")
    private Integer warehouseLocation;
    
    public StockItems(){
    }
    
    public StockItems(String stockcode, String stockname, String storageLocation, Integer quantity, String stockDescription, Integer warehouseLocation){
        
        this.stockcode = stockcode;
        this.stockname = stockname;
        this.storageLocation = storageLocation;
        this.quantity = quantity;
        this.stockDescription = stockDescription;
        this.warehouseLocation = warehouseLocation;
    }
    
    public String getStockCode(){
        return stockcode;
    }
    
    public void setStockCode(String stockcode){
        this.stockcode = stockcode;
    }
    
    public String getStockName(){
        return stockname;
    }
    
    public void setStockName(String stockname){
        this.stockname = stockname;
    }
    
    public String getStorageLocation(){
        return storageLocation;
    }
    
    public void setStorageLocation(String storageLocation){
        this.storageLocation = storageLocation;
    }
    
    public Integer getQuantity(){
        return quantity;
    }
    
    public void setQuantity(Integer quantity){
        this.quantity = quantity;
    }
    
    public String getStockDescription(){
        return stockDescription;
    }
    
    public void setStockDescription(String stockDescription){
        this.stockDescription = stockDescription;
    }
    
    public Integer getWarehouseLocation(){
        return warehouseLocation;
    }
    
    public void setWarehouseLocation(Integer warehouseLocation){
        this.warehouseLocation = warehouseLocation;
    }
    
}
