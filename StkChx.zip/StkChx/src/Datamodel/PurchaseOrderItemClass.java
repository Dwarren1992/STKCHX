/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datamodel;

/**
 *
 * @author Warren
 */
import com.fasterxml.jackson.annotation.JsonProperty;

public class PurchaseOrderItemClass {
    
    @JsonProperty("PURCHASEORDERID")
    private Integer purchaseOrderID;
    @JsonProperty("STOCKCODE")
    private String stockcode;
    @JsonProperty("QUANTITY")
    private Integer quantity;
    
    
    public PurchaseOrderItemClass(){
    }
    
    public PurchaseOrderItemClass(Integer purchaseOrderID, String stockcode, Integer quantity){
        
        this.purchaseOrderID = purchaseOrderID;
        this.stockcode = stockcode;
        this.quantity = quantity;
    }
    
    public Integer getPurchaseOrderID(){
        return purchaseOrderID;
    }
    
    public void setPurchaseOrderID(Integer purchaseOrderID){
        this.purchaseOrderID = purchaseOrderID;
    }
    
    public String getStockcode(){
        return stockcode;
    }
    
    public void setStockcode(String stockcode){
        this.stockcode = stockcode;
    }
    
    public void setPurchaseOrderItemsID(String stockcode){
        this.stockcode = stockcode;
    }
    
    public Integer getQuantity(){
        return quantity;
    }
    
    public void setQuantity(Integer quantity){
        this.quantity = quantity;
    }
}
